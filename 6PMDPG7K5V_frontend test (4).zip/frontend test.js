function ValidateEmail(inputText) {
     var mailformat = /^\w+([\.-]?\w+)*@gmail.com\w+([\.-]?\w+)*(\.\w{2,3})+$/;
     var letterNumber = /^[0-9a-zA-Z]/;
     if (inputText.value.match(mailformat) && (inputPassword.value.match(letterNumber))) {
         alert("Login successful");
         document.form1.text1.focus();
         return true;
     } else {
         alert("Login failed");
         document.form1.text1.focus();
         return false;
     }
 }